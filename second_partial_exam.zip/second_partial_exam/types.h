#ifndef TYPES_H
#define TYPES_H

typedef unsigned int u32;
typedef unsigned char u8;


#endif
